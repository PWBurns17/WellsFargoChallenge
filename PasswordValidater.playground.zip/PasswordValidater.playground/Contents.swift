import Foundation

func validate(password: String) -> String {
    
    // creating patterns for regex
    let numberPattern = "[^0-9]"
    let specialCharsPattern = "[^!@#$%^&*?]"
    
    // create the indexes range of the string
    let range = (password.startIndex..<password.endIndex)
    
    let hasNumberChars = !password.replacingOccurrences(of: numberPattern, with: "", options: .regularExpression, range: range).isEmpty
    let hasSpecialChars = !password.replacingOccurrences(of: specialCharsPattern, with: "", options: .regularExpression, range: range).isEmpty
    
    if hasNumberChars && hasSpecialChars {
        return "Strong"
    } else if hasNumberChars || hasSpecialChars {
        return "Medium"
    } else {
        return "Weak"
    }
    
}


print(validate(password: "TEST"))
print(validate(password: "test123%"))
print(validate(password: "te12%"))
print(validate(password: "Test123"))
print(validate(password: "Test%"))
print(validate(password: "testpwd"))
print(validate(password: "Test123%"))
